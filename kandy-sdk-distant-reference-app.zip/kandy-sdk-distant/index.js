import * as Controller from './controller';

var domContainer = document.querySelector('#react_root');
var root = ReactDOM.createRoot(domContainer);
root.render(React.createElement(Controller.Component, { sessionId: 42 }));
