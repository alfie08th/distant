# Introduction

In the next few sections we will walk through the steps necessary to building a successful Distant application. We will try to adhere to certain principles that will allow this application to be easily maintained and extended in the future.

Here are the assumptions that we are making:

1. We're developing a desktop Electron WebRTC application that can provide good performance with media in a VDI environment.
2. The application can run in both VDI and non-VDI mode.
3. This will require some advanced knowledge of JavaScript but only limited knowledge of VDI.
4. We will be using modern language features (ES2018+) and modern methodologies and tools.
5. We don't want to compromise on having quick iterative development environment.

Let's get [started small](./starting-small.md).
