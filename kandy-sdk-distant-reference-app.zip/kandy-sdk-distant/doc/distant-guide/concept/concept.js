import { openVirtualChannel } from 'vchannel'
import { fromVirtualChannel } from 'pull-vchannel'
import { createSessionManager } from 'distant'

const channel = await openVirtualChannel('RIBBON')
const duplexStream = fromVirtualChannel(channel)

const sessionManager = createSessionManager(duplexStream)

const distantSession = sessionManager.createSession(appBundle)
