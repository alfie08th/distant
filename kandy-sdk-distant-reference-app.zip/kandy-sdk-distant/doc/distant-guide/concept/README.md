Note:

The code in the concept folder is there to capture the feelings of working with the distant SDK, it's not meant as a blue print, but rather for inspiration.
