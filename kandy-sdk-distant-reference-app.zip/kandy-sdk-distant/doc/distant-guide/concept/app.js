import Distant from 'distant'
import { openVirtualChannel } from 'vchannel'
import { pull } from 'pull-stream'
import Kandy from 'kandy'


let vdiMode = false

// Connection to the channel
try {
  const channel = openVirtualChannel('Kandy')
  vdiMode = true
} catch (err) {
  console.log(err)
}


if (vdiMode) {

  // At this point the channel is a byte array channel that doesn't perform any special processing to the data
  const distantConnection = Distant.fromStream(fromChannel(channel))

  const distantApp = await distantConnection.loadApp(appBundle, {
    // The kandy channel, pass that to Kandy media proxy.
    kandy: 'duplex',
    
    // Application defined channels
    sendMessage: 'async',
    getEvent: 'async',


    windowPos: 'duplex'
  })
}

// In my redux app

const middleware = store => next => action => {
  if (action.type === 'MOVE_WINDOW') {
    distantApp.remote.dispatch(action)
  }
}

pull(
  distantApp.remote.state
  drain((data) => {
    reduxStore.dispatch(actions.remoteData(data))
  })
)


// API for application
const kandy = Kandy.create();


if (vdiMode) {
  kandy.mediaProxy.connect({  
    stream: distantApp.remote.kandy
  });
}

const callId = kandy.call.make('myfriend@kandy.io')

kandy.on('call:start', ({callId}) => {
  
  const call = kandy.call.getById(callId)


  // Use the media container mappings? Or provide a higher level abstraction? Or let the app handle rendering on the remote?

  if (vdiMode){
    kandy.mediaProxy.render(call.localMedia, '#localVideoContainer')
    kandy.mediaProxy.render(call.remoteMedia, '#remoteVideoContainer')
  } else {
    kandy.media.render(call.localMedia, '#localVideoContainer')
    kandy.media.render(call.remoteMedia, '#remoteVideoContainer')
  }
})

function doManipulationOnVideoContainer() {
  if (vdiMode) {
    distantApp.remote.dispatch(actions.moveWindow())

  } else {

  }
}

// HTML



<div id="localVideoContainer"></div>
<div id="remoteVideoContainer"></div>







