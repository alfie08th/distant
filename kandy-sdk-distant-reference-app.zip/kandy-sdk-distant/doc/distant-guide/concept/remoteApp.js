import { openVirtualChannel } from 'vchannel'
import Distant from 'distant'

// Connection to the channel
try {
  const channel = openVirtualChannel('Kandy')
} catch (err) {
  console.log(err)
}

const serverApp = DistantRemote.fromStream(fromChannel(channel))

const kandy = Kandy.create('MediaProxyOnly')

kandy.mediaProxy.connect(serverApp.remote.kandy)
