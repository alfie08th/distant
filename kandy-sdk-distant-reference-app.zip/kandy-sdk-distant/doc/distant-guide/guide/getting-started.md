# Getting Started

## Installation

### JavaScript packages

All of the javascript libraries are provided as Node modules that can also run in the browser using a package bundler like WebPack, Rollup, Parcel.

Using npm:

```shell
$ npm install @distant/distant
```

Using yarn:

```shell
$ yarn add @distant/distant
```

See the list of available modules [here](./modules.md)

### Distant VDI

Distant VDI comes in the form of a dynamic library that gets loaded into the Citrix Receiver process at runtime.

#### EPM package

Distant VDI is distributed as a Scout Enterprise EPM package for use with eLux RP thin-clients.
