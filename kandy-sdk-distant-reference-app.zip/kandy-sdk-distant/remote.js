import * as RemoteApp from './remote-app';

var domContainer = document.querySelector('#react_root');
var root = ReactDOM.createRoot(domContainer);
root.render(React.createElement(RemoteApp.Component));
