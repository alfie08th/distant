const path = require('path');

module.exports = {
  mode: "production",
  entry: {
      main: './index.js',
      remote: './remote.js'
  },
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: '[name].js',
  },
  module: {
      rules: [
          // All output '.js' files will have any sourcemaps re-processed by 'source-map-loader'.
          {
              enforce: "pre",
              test: /\.js$/,
              loader: "source-map-loader"
          },
      ]
  },
  externals: {
      "react": "React",
      "react-dom": "ReactDOM",
      "kandy": "Kandy",
  },
};
