import * as Media from './media'


export class Component extends React.Component {
	constructor(props) {
    super(props);
		this.state = {
			connected:false,
			callId:undefined,
			messages:[],
			video:false,
			connectionPending:false,
		}
		if(this.props.config.username && this.props.config.password) {
			this.props.getKandy().setCredentials({
				username:props.config.username,
				password:props.config.password,
			})
		}
		this.props.getKandy().on(
			"subscription:change",
			(params)=>{
				let subscriptions=this.props.getKandy().services.getSubscriptions()
				this.setState({
					connected:subscriptions.subscribed.length>0,
					connectionPending:subscriptions.isPending,
					messages:this.state.messages.concat(
						`Subscription changed: ${subscriptions.subscribed} ${params.reason||""}`,
					)
				})
			}
		)
		this.props.getKandy().on(
			"subscription:error",
			(params)=>{
				this.setState({
					connected:false,
					connectionPending:false,
					messages:this.state.messages.concat(
						`Subscription error: ${params.error.message}`,
					)
				})
			}
		)
		this.props.getKandy().on(
			"call:start",
			(params)=>this.setState({
				messages:this.state.messages.concat(`Call started: ${params.callId}`)
			})
		)
		this.props.getKandy().on(
			"call:error",
			(params)=>this.setState({
				messages:this.state.messages.concat(`Call error: ${params.error.message}`)
			})
		)
		this.props.getKandy().on(
			"call:stateChange",
			(params)=>this.callStateChanged(params),
		)
		this.props.getKandy().on(
			"call:newTrack",
			(params)=>this.trackStarted(params),
		)
		this.props.getKandy().on(
			"call:trackEnded",
			(params)=>this.trackEnded(params),
		)
  }

	callStateChanged(params) {
		let call=this.props.getKandy().call.getById(params.callId)
		let messages=[
			`Call state changed from ${params.previous.state} to ${call.state}`
		]
		if(params.error) {
			messages=messages.concat(
				`Call error ${params.error.message}`
			)
		}
		messages.forEach((m)=>console.log(m))
		this.setState({
			callId:('ENDED'==call.state.toUpperCase())?undefined:this.state.callId,
			messages:this.state.messages.concat(messages),
		})
	}

	makeCall() {
		if(!this.state.callId) {
			this.setState({
				callId:this.props.getKandy().call.make(
					this.props.config.destination,
					{audio:true,video:this.state.video,}
				),
			})
		}
	}

	endCall() {
		if(this.state.callId) {
			this.props.getKandy().call.end(this.state.callId)
			this.setState({
				callId:undefined,
			})
		}
	}

	trackStarted(params) {
		let kandy=this.props.getKandy()
		let track=kandy.media.getTrackById(params.trackId)
		if(!track) {
			this.setState({
				messages:this.state.messages.concat(
					`Could not render track ${params.trackId}`
				)
			})
		} else {
			this.setState({
				messages:this.state.messages.concat(
					`Rendering ${params.local?"local":"remote"} ${track.kind} track`,
				),
			})

			if(params.local) {
				if("video"==track.kind) {
					kandy.media.renderTracks(
						[params.trackId],
						`#${Media.Component.LOCAL_CONTAINER_ELEMENT}`,
					)
				}
			} else {
				kandy.media.renderTracks(
					[params.trackId],
					`#${Media.Component.REMOTE_CONTAINER_ELEMENT}`,
				)
			}
		}
	}
	trackEnded(params) {
		let kandy=this.props.getKandy()
		let track=kandy.media.getTrackById(params.trackId)
		if(!track) {
			this.setState({
				messages:this.state.messages.concat(
					`Could not remove track ${params.trackId}`
				)
			})
		} else {
			this.setState({
				messages:this.state.messages.concat(
					`Removing ${params.local?"local":"remote"} ${track.kind} track`,
				),
			})

			if(params.local) {
				if("video"==track.kind) {
					kandy.media.removeTracks(
						[params.trackId],
						`#${Media.Component.LOCAL_CONTAINER_ELEMENT}`,
					)
				}
			} else {
				kandy.media.removeTracks(
					[params.trackId],
					`#${Media.Component.REMOTE_CONTAINER_ELEMENT}`,
				)
			}
		}
	}

	toggleSubscription() {
		let message
		if(this.state.connected) {
			this.props.getKandy().services.unsubscribe(this.props.services)
			message=`Unsubscribing...`
		} else {
			this.props.getKandy().services.subscribe(this.props.services)
			message=`Subscribing...`
		}
		this.setState({
			messages:this.state.messages.concat(message),
			connectionPending:true,
		})
	}

  render() {
    return (
			<React.Fragment>
				<div>
					<button
						type="button"
						onClick={(event)=>this.toggleSubscription()}
						disabled={this.state.connectionPending}
					>
						{this.state.connected
							?(this.state.connectionPending?"Disconnecting...":"Disconnect")
							:(this.state.connectionPending?"Connecting...":"Connnect")
						}
					</button>
				</div>
				<div>
					<label>Destination</label>
					<input
						type="text"
						onChange={(event)=>this.props.setConfig(
							Object.assign(this.props.config,{
								destination:event.currentTarget.value,
							}),
						)}
						value={this.props.config.destination}
					/>
					<button
						type="button"
						onClick={(event)=>this.makeCall()}
						disabled={
							!this.state.connected ||
							0==this.props.config.destination.length ||
							this.state.callId
						}
					>
						Make Call
					</button>
					<button
						type="button"
						onClick={(event)=>this.endCall()}
						disabled={!this.state.callId}
					>
						End Call
					</button>
					<label>
						{`With video`}
					</label>
					<input
						type="checkbox"
						onChange={(event)=>this.setState({
							video:event.currentTarget.checked,
						})}
						checked={this.state.video}
					/>
				</div>
				<div>
					{this.state.messages.map((message)=><div>{message}</div>)}
				</div>
				{(!this.props.proxyMode && this.state.callId)?<Media.Component/>:null}
			</React.Fragment>
		)
  }
}
