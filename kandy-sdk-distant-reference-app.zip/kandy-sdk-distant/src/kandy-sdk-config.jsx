export class Config {
	static SERVICES=["call"]
	static load() {
		let config=new Config()
		config.username=localStorage.getItem("distant-username")||"username"
		config.password=localStorage.getItem("distant-password")||"password"
		config.server=localStorage.getItem("distant-server")||"localhost"
		config.destination=localStorage.getItem("distant-destination")||""
		return config
	}
	static update(config,kandy) {
		localStorage.setItem("distant-username",config.username)
		localStorage.setItem("distant-password",config.password)
		localStorage.setItem("distant-server",config.server)
		localStorage.setItem("distant-destination",config.destination)
		kandy.setCredentials({
			username:config.username,
			password:config.password,
		})
		kandy.updateConfig(Config.getSdk(config))
		return config
	}
	static getSdk(config) {
		return {
			authentication: {
				server: {
					base: config.server,
				},
			},
			subscription: {
				websocket: {
					server: config.server,
				},
			},
			common: {
	      allowProxy: true // Allow SDK to include Proxy Plugin.
	    },
		}
	}
}

export class Component extends React.Component {

	constructor(props) {
    super(props);
    this.state = {
		}
  }

  render() {
    return (
				<React.Fragment>
					<div>
						<label>Username</label>
						<input
							type="text"
							onChange={(event)=>this.props.setConfig(
								Object.assign(this.props.config,{
									username:event.currentTarget.value,
								}),
							)}
							value={this.props.config.username}
						/>
						<label>Password</label>
						<input
							type="password"
							onChange={(event)=>this.props.setConfig(
								Object.assign(this.props.config,{
									password:event.currentTarget.value,
								}),
							)}
							value={this.props.config.password}
						/>
						<label>Server</label>
						<input
							type="text"
							onChange={(event)=>this.props.setConfig(
								Object.assign(this.props.config,{
									server:event.currentTarget.value,
								}),
							)}
							value={this.props.config.server}
						/>
					</div>
				</React.Fragment>
		)
  }
}
