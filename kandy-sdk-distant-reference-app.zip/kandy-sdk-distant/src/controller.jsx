import { createController } from '@distant/distant'
import { createConnection } from '@distant/distant-web'
import { createDistantJSONCodec } from '@distant/distant-codecs'
import { ApplicationMessage } from './application-message'
import * as KandySdk from './kandy-sdk'
import * as KandySdkConfig from './kandy-sdk-config'


export class Component extends React.Component {

	static INIT_MODE_ZERO=0
	static INIT_MODE_PENDING_READY=1
	static INIT_MODE_READY=2
	static INIT_MODE_PENDING_ZERO=4

	constructor(props) {
    super(props);
		this.distantConnection=createConnection()
		this.distantController=createController(this.distantConnection)
		this.codec=createDistantJSONCodec()
		this.session=undefined
		this.pingTimeout=undefined
		this.kandySdkChannel=undefined
		this.kandySdkChannelMode=Component.INIT_MODE_ZERO,
		this.kandySdkProxyMode=Component.INIT_MODE_ZERO,
    this.state = {
			remoteApplicationUrl:"remote.html",
			message:"hello",
			sessionId:undefined,
			pingInterval:5000,
			pongReceived:false,
			closeIfNoPong:false,
			sendPing:false,
			windowVisible:false,
			kandySdkConfig:KandySdkConfig.Config.load(),
		};
		this.kandy=Kandy.create(
			KandySdkConfig.Config.getSdk(this.state.kandySdkConfig),
		)
		this.kandy.on("proxy:change",(params)=>{
			// get proxy details is emptry?
			let proxyDetails=this.kandy.proxy.getProxyDetails()
			if(Component.INIT_MODE_PENDING_READY==this.kandySdkChannelMode) {
				this.kandySdkChannelMode=Component.INIT_MODE_READY
				if(Component.INIT_MODE_ZERO==this.kandySdkProxyMode) {
					this.kandySdkProxyMode=Component.INIT_MODE_PENDING_READY
					setTimeout(()=>this.kandy.proxy.setProxyMode(true),0)
				}
			} else if(Component.INIT_MODE_PENDING_READY==this.kandySdkProxyMode) {
				this.kandySdkProxyMode=Component.INIT_MODE_READY
				this.kandy.proxy.initializeRemote()
			} else if(Component.INIT_MODE_PENDING_ZERO==this.kandySdkProxyMode) {
				this.kandySdkProxyMode=Component.INIT_MODE_ZERO
			}
			console.log(`proxy:change | channel=${this.kandySdkChannelMode}, proxy=${this.kandySdkProxyMode}, getProxyDetails=${JSON.stringify(proxyDetails)}`)
		})
  }

	createSession() {
    const session=this.distantController.createSession({
			id: this.props.sessionId,
			targetUrl: this.state.remoteApplicationUrl,
			timeout: 5000,
		}).then(
			(session)=>this.sessionCreated(session),
			(err)=>console.log(err.message),
		)
	}

	sessionCreated(session) {
		console.log(`Session created (${session.getInfo().id}) for ${this.state.remoteApplicationUrl}`)
		console.log(`Session getInfo (${Boolean(session.getInfo)})`)
		console.log(`Session sendMessage (${Boolean(session.sendMessage)})`)
		this.session=session
		this.session.on('message',(encoded)=>this.receiveMessage(encoded))
		// remainder of initialisation after remote ready message
		this.setState({
			sessionId:session.getInfo().id,
			windowVisible:true,
		})
		this.pingTimeout=setTimeout(()=>this.sendPing(),this.state.pingInterval)
	}

	closeSession() {
		if(this.session) {
			this.session.close().then(()=>{
				if(this.pingTimeout) {
					clearTimeout(this.pingTimeout)
					this.pingTimeout=undefined
				}
				this.session=undefined
				this.setState({
					sessionId:undefined,
				})
				this.kandySdkProxyMode=Component.INIT_MODE_PENDING_ZERO
				setTimeout(()=>this.kandy.proxy.setProxyMode(false),0)
			})
		}
	}

	setWindowVisible(visible) {
			ApplicationMessage.sendSetWindowVisible(this.session,this.codec,visible)
			this.setState({
				windowVisible:visible,
			})
	}

	receiveMessage(encoded) {
		console.log("Received encoded message")
		let message = ApplicationMessage.parse(encoded,this.codec)
		if(!message) {
			console.log("Failed to parse encoded message")
		} else if(!message.processKandySdkMessage(this.kandySdkChannel)) {
			console.log(`Received ${JSON.stringify(message)}`)
			if(message.isPong()) {
				console.log("Received pong")
				this.setState({
					pongReceived:true,
				})
			} else if(message.isRemoteReady()) {
				if(this.session) {
					this.kandySdkChannelMode=Component.INIT_MODE_PENDING_READY
					this.kandySdkChannel=ApplicationMessage.createKandySdkChannel(
						this.session,
						this.codec,
					)
					this.kandy.proxy.setChannel(this.kandySdkChannel)
					console.log(
						`Kandy SDK channel is set: send=${Boolean(this.kandySdkChannel.send)}, receive=${Boolean(this.kandySdkChannel.receive)}`
					)
					// seems to be a race condition with this... wait for proxy:change
					//this.kandy.proxy.setProxyMode(true)
				}
			}
		}
	}

	sendPing() {
		if(this.session) {
			if(this.state.sendPing) {
				console.log("Sending ping")
				ApplicationMessage.sendPing(this.session,this.codec)
			}
			this.setState({
				pongReceived:false,
			})
			this.pingTimeout=setTimeout(()=>this.pongTimeout(),this.state.pingInterval)
		}
	}

	pongTimeout() {
		if(!this.state.pongReceived && this.state.sendPing) {
			console.log(`No pong received in ${this.state.pingInterval}ms`)
		}

		if(!this.state.pongReceived && this.state.closeIfNoPong) {
			this.closeSession()
		} else {
			this.sendPing()
		}
	}

	pongReceived() {
		this.setState({
			pongReceived:true,
		})
	}

  render() {
    return (
				<React.Fragment>
					<div>
						<div>
							<input
								type="text"
								onChange={(event)=>this.setState({
									remoteApplicationUrl:event.currentTarget.value,
								})}
								value={this.state.remoteApplicationUrl}
							/>
							<button
								type="button"
								onClick={(event)=>this.createSession()}
								disabled={this.session}
							>
								{`Create Session ${this.props.sessionId}`}
							</button>
							<button
								type="button"
								onClick={(event)=>this.setWindowVisible(!this.state.windowVisible)}
								disabled={!this.state.sessionId}
							>
								{this.state.windowVisible?"Hide Window":"Show Window"}
							</button>
							<button
								type="button"
								onClick={(event)=>this.closeSession()}
								disabled={!this.state.sessionId}
							>
								{`Close Session`}
							</button>
						</div>
						<div>
							<input
								type="text"
								onChange={(event)=>this.setState({
									message:event.currentTarget.value,
								})}
								value={this.state.message}
							/>
							<button
								type="button"
								id="message-send"
								onClick={(event)=>ApplicationMessage.sendText(
									this.session,
									this.codec,
									this.state.message,
								)}
								disabled={
									!this.state.sessionId
								}
							>
								Send
							</button>
						</div>
						<div>
							<label>
								{`Send ping at ${this.state.pingInterval}ms`}
							</label>
							<input
								type="checkbox"
								onChange={(event)=>this.setState({
									sendPing:event.currentTarget.checked,
								})}
								checked={this.state.sendPing}
							/>
							<label>
								{`Close if no pong at ${this.state.pingInterval}ms`}
							</label>
							<input
								type="checkbox"
								onChange={(event)=>this.setState({
									closeIfNoPong:event.currentTarget.checked,
								})}
								checked={this.state.closeIfNoPong}
							/>
						</div>
					</div>
					<KandySdkConfig.Component
						config={this.state.kandySdkConfig}
						setConfig={(config)=>this.setState({
							kandySdkConfig:KandySdkConfig.Config.update(config,this.kandy),
						})}
					/>
					<KandySdk.Component
						config={this.state.kandySdkConfig}
						getKandy={()=>this.kandy}
						services={KandySdkConfig.Config.SERVICES}
						setConfig={(config)=>this.setState({
							kandySdkConfig:KandySdkConfig.Config.update(config,this.kandy),
						})}
						proxyMode={Boolean(this.state.sessionId)}
					/>
				</React.Fragment>
		)
  }
}
