import { createDistantJSONCodec } from '@distant/distant-codecs'


export class Component extends React.Component {

	constructor(props) {
    super(props);
		this.codec=createDistantJSONCodec()
    this.state = {
			liked: false,
			message: "",
			encoded: [],
			decoded: {},
		};
  }

  render() {
    return (
				<React.Fragment>
					<div>
						<input
							type="text"
							id="message-text"
							onChange={(event)=>this.setState({
								message:event.currentTarget.value,
								encoded:[],
								decoded:{},
							})}
							value={this.state.message}
						/>
						<button
							type="button"
							id="message-encode"
							onClick={(event)=>{
								console.log(this.state.message)
								let toencode={message:this.state.message}
								console.log(JSON.stringify(toencode))
								let encoded=this.codec.encode(toencode)
								if(encoded) {
									console.log(encoded)
									this.setState({
										encoded:encoded,
										decoded:{},
									})
								} else {
									console.log("Could not encode "+toencode)
								}
							}}
							disabled={0==this.state.message.length}
						>
							Encode
						</button>
					</div>
					<div>
						<input
							type="text"
							id="message-decoded"
							value={this.state.decoded.message||""}
						/>
						<button
							type="button"
							id="message-decode"
							onClick={(event)=>{
								console.log(this.state.encoded)
								let decoded=this.codec.decode(this.state.encoded)
								console.log(decoded)
								this.setState({
									decoded:decoded,
								})
							}}
							disabled={0==this.state.encoded.length}
						>
							Decode
						</button>
					</div>
				</React.Fragment>
		)
  }
}
