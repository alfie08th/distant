
class KandySdkChannel {
	constructor(session,codec) {
		this.session=session
		this.codec=codec
		this.send=(data)=>new ApplicationMessage(
			ApplicationMessage.MESSAGE_KANDY_SDK_CHANNEL_DATA,
			data,
		).send(this.session,this.codec)
		this.receive=undefined
	}
}

export class ApplicationMessage {
	static MESSAGE_TYPE_APPLICATION="@@APPLICATION"
	static MESSAGE_TYPE_KANDY_SDK_CHANNEL="@@KANDY_SDK_CHANNEL"
	static MESSAGE_REMOTE_READY=ApplicationMessage.MESSAGE_TYPE_APPLICATION+"/REMOTE_READY"
	static MESSAGE_PING=ApplicationMessage.MESSAGE_TYPE_APPLICATION+"/PING"
	static MESSAGE_PONG=ApplicationMessage.MESSAGE_TYPE_APPLICATION+"/PONG"
	static MESSAGE_TEXT=ApplicationMessage.MESSAGE_TYPE_APPLICATION+"/TEXT"
	static MESSAGE_SET_WINDOW_VISIBLE=ApplicationMessage.MESSAGE_TYPE_APPLICATION+"/SET_WINDOW_VISIBLE"
	static MESSAGE_KANDY_SDK_CHANNEL_DATA=ApplicationMessage.MESSAGE_TYPE_KANDY_SDK_CHANNEL+"/DATA"
	constructor(type,body={}) {
		this.type=type
		this.body=body
	}
	static sendRemoteReady(session,codec) {
		return new ApplicationMessage(
			ApplicationMessage.MESSAGE_REMOTE_READY
		).send(session,codec)
	}
	static sendPing(session,codec) {
		return new ApplicationMessage(
			ApplicationMessage.MESSAGE_PING
		).send(session,codec)
	}
	static sendPong(session,codec) {
		return new ApplicationMessage(
			ApplicationMessage.MESSAGE_PONG
		).send(session,codec)
	}
	static sendText(session,codec,text) {
		return new ApplicationMessage(
			ApplicationMessage.MESSAGE_TEXT,
			{text:text},
		).send(session,codec)
	}
	static sendSetWindowVisible(session,codec,visible) {
		return new ApplicationMessage(
			ApplicationMessage.MESSAGE_SET_WINDOW_VISIBLE,
			{visible:visible}
		).send(session,codec)
	}
	isApplicationMessage(type) {
		return this.type.startsWith(ApplicationMessage.MESSAGE_TYPE_APPLICATION)
	}
	isRemoteReady() {
		return [ApplicationMessage.MESSAGE_REMOTE_READY].includes(this.type)
	}
	isPing() {
		return [ApplicationMessage.MESSAGE_PING].includes(this.type)
	}
	isPong() {
		return [ApplicationMessage.MESSAGE_PONG].includes(this.type)
	}
	isText() {
		return [ApplicationMessage.MESSAGE_TEXT].includes(this.type)
	}
	isSetWindowVisible() {
		return [ApplicationMessage.MESSAGE_SET_WINDOW_VISIBLE].includes(this.type)
	}
	static createKandySdkChannel(session,codec) {
		return new KandySdkChannel(session,codec)
	}
	processKandySdkMessage(channel) {
		let processed=false
		if([ApplicationMessage.MESSAGE_KANDY_SDK_CHANNEL_DATA].includes(this.type)) {
			if(channel.receive) {
				console.log(`Pushing message to Kandy SDK: ${JSON.stringify(this.body)}`)
				channel.receive(this.body)
			} else {
				console.log(`Kandy SDK has no receiver`)
			}
			processed=true
		}
		return processed
	}

	static parse(encoded,codec) {
		let message=codec.decode(encoded)
		if(message && message.type && message.body) {
			message=new ApplicationMessage(message.type,message.body)
		}
		return message
	}

	send(session,codec) {
		let message={
			type:this.type,
			body:this.body,
		}
		let encodedMessage=codec.encode(message)
		if(encodedMessage) {
			console.log(`Encoded message to send is ${encodedMessage.length} long: ${JSON.stringify(message)}`)
			session.sendMessage(encodedMessage)
		} else {
			console.log(`Failed to encode message, cannot send: ${JSON.stringify(message)}`)
		}
	}
}
