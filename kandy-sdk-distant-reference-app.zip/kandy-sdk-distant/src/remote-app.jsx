import { createController } from '@distant/distant'
import { createConnection } from '@distant/distant-web'
import { createDistantJSONCodec } from '@distant/distant-codecs'
import remoteController from '@distant/distant-remote'
import * as Controller from './controller'
import * as Media from './media'
import { ApplicationMessage } from './application-message'

export class Component extends React.Component {

	constructor(props) {
    super(props);
		this.codec=createDistantJSONCodec()
		this.kandySdkChannel=undefined
		this.kandy=Kandy.create()
		this.kandy.on("initialize",()=>this.setState({
			messages:this.state.messages.concat("Remote initialisation"),
		}))
		if(remoteController) {
			remoteController.on('message', (encoded) => this.receiveMessage(encoded))
			this.kandySdkChannel=ApplicationMessage.createKandySdkChannel(
				remoteController,
				this.codec,
			)
			this.kandy.proxy.setChannel(this.kandySdkChannel)
			ApplicationMessage.sendRemoteReady(remoteController,this.codec)
		}
		this.state={
			lastMessage:"",
			applicationMessageCount:0,
			pingMessageCount:0,
			totalMessageCount:0,
			sendPong:true,
			messages:[],
		}
  }

	receiveMessage(encoded) {
		// Message received from the controller.
		console.log("Received encoded message")
		// First let's decode it.
		let message = ApplicationMessage.parse(encoded,this.codec)
		let displayMessage=this.state.lastMessage
		let applicationMessageCount=this.state.applicationMessageCount
		let pingMessageCount=this.state.pingMessageCount

		if(message && !message.processKandySdkMessage(this.kandySdkChannel)) {

			console.log(`Received ${JSON.stringify(message)}`)
			if(message.isPing()) {
				pingMessageCount+=1
				if(this.state.sendPong) {
					ApplicationMessage.sendPong(remoteController,this.codec)
				}

			} else if (message.isText() && message.body.text) {
				displayMessage=message.body.text

			} else if (message.isSetWindowVisible()) {
				if(remoteController.setWindowVisible) {
					remoteController.setWindowVisible(message.body.visible)
				} else {
					console.log("Controller has no setWindowVisible")
				}

			} else {
				displayMessage="unexpected"
			}
			applicationMessageCount+=1
		}
		this.setState({
			lastMessage:displayMessage,
			applicationMessageCount:applicationMessageCount,
			pingMessageCount:pingMessageCount,
			totalMessageCount:this.state.totalMessageCount+1
		})
	}

  render() {
		let localVideoStyle:React.CSSProperties={
			width:"160px",
			height:"120px",
			backgroundColor:"blue",
		}
		let remoteVideoStyle:React.CSSProperties={
			width:"160px",
			height:"120px",
			backgroundColor:"green",
		}
    return remoteController?(
				<React.Fragment>
					<div>
						<label>
							{`Send pong when ping is received`}
						</label>
						<input
							type="checkbox"
							onChange={(event)=>this.setState({
								sendPong:event.currentTarget.checked,
							})}
							checked={this.state.sendPong}
						/>
					</div>
					<div>
						<label>
							{`Messages (${this.state.applicationMessageCount}/${this.state.pingMessageCount}/${this.state.totalMessageCount}):`}
						</label>
						<input
							type="text"
							value={this.state.lastMessage}
							disabled={true}
						/>
					</div>
					<Media.Component/>
					<div>
						{this.state.messages.map((message)=><div>{message}</div>)}
					</div>
				</React.Fragment>
		):(
			<div>Application only functions if launched from distant session</div>
		)
  }
}
