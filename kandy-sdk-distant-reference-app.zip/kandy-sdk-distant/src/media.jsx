
export class Component extends React.Component {
	static REMOTE_CONTAINER_ELEMENT="remote-container"
	static LOCAL_CONTAINER_ELEMENT="local-container"
  render() {
		let localVideoStyle={
			width:"160px",
			height:"120px",
			backgroundColor:"blue",
		}
		let remoteVideoStyle={
			width:"160px",
			height:"120px",
			backgroundColor:"green",
		}

    return (
			<React.Fragment>
				<div
					id={Component.REMOTE_CONTAINER_ELEMENT}
					style={remoteVideoStyle}
				/>
				<div
					id={Component.LOCAL_CONTAINER_ELEMENT}
					style={localVideoStyle}
				/>
			</React.Fragment>
		)
  }
}
